# Nitro-type-car-hack
These javascripts are made for changing the look of your garage and dealership on Nitro type and adding some extra cars in your garage.

Those extra cars are visual only, so you will be able to use them in practice races only.

Need any help regarding these scripts? - Message me on Facebook -> www.facebook.com/PrabhakarRaiOfficial
